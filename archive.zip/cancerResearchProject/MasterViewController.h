//
//  MasterViewController.h
//  cancerResearchProject
//
//  Created by THM on 8/25/13.
//  Copyright (c) 2013 THM. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;

@end
